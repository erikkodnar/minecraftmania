
package net.mcreator.jessiejane.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class PearlingotItem extends Item {
	public PearlingotItem() {
		super(new Item.Properties().stacksTo(64).rarity(Rarity.COMMON));
	}
}
