package net.mcreator.jessiejane.procedures;

public class FireExplosionProcedure {
	public static void execute() {
	}
}
